import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

import { DataService } from '../data.service';

@Component({
  selector: 'app-item-form',
  templateUrl: './item-form.component.html',
  styleUrls: ['./item-form.component.scss']
})
export class ItemFormComponent implements OnInit {
  item: any = { id: null, name: '', email: '' };
  isEdit = false;

  constructor(private dataService: DataService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEdit = true;
      this.dataService.getItem(+id).subscribe(item => this.item = item);
    }
  }

  save(): void {
    if (this.isEdit) {
      this.dataService.updateItem(this.item).subscribe(() => this.router.navigate(['/items']));
    } else {
      this.dataService.createItem(this.item).subscribe(() => this.router.navigate(['/items']));
    }
  }
}
