import { AfterViewInit, Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { Feature, LineString } from 'geojson';
import mapboxgl, { GeoJSONSource } from 'mapbox-gl';

@Component({
  selector: 'app-map-box',
  templateUrl: './map-box.component.html',
  styleUrls: ['./map-box.component.scss']
})

  export class MapBoxComponent implements OnInit, AfterViewInit, OnChanges {
  
    @Input() pickup: string = '';
    @Input() dropoff: string = '';
    map!: mapboxgl.Map;
    accessToken = 'pk.eyJ1Ijoic2FpbmF0aDI1MTAiLCJhIjoiY20wM2QwbXVoMDloajJxc2N6emg0NmJhNyJ9.DhuqEN_rlQk5czrJ0nOvKQ';
  
    constructor() { }
  
    ngOnInit(): void { }
  
    ngAfterViewInit(): void {
      this.initializeMap();
    }
  
    ngOnChanges(changes: SimpleChanges) {
      if (this.pickup && this.dropoff) {
        this.displayRoute(this.pickup, this.dropoff);
      }
    }
  
    initializeMap() {
      mapboxgl.accessToken = this.accessToken;
  
      this.map = new mapboxgl.Map({
        container: 'map',
        style: 'mapbox://styles/mapbox/streets-v11',
        center: [-74.5, 40], // Initial map center [lng, lat]
        zoom: 9
      });
    }

    displayRoute(pickupAddress: string, dropoffAddress: string) {
      Promise.all([
        this.geocodeAddress(pickupAddress),
        this.geocodeAddress(dropoffAddress)
      ])
      .then(([pickupCoords, dropoffCoords]) => {
        const accessToken = this.accessToken;
        const directionsRequest = `https://api.mapbox.com/directions/v5/mapbox/driving/${pickupCoords.join(',')};${dropoffCoords.join(',')}?steps=true&geometries=geojson&access_token=${accessToken}`;
    
        return fetch(directionsRequest);
      })
      .then(response => response.json())
      .then(data => {
        const route = data.routes[0].geometry.coordinates;
        const geojson: Feature<LineString> = {
          type: 'Feature',
          properties: {},
          geometry: {
            type: 'LineString',
            coordinates: route
          }
        };
    
        const source = this.map.getSource('route') as GeoJSONSource;
        if (source) {
          source.setData(geojson);
        } else {
          this.map.addLayer({
            id: 'route',
            type: 'line',
            source: {
              type: 'geojson',
              data: geojson
            },
            layout: {
              'line-join': 'round',
              'line-cap': 'round'
            },
            paint: {
              'line-color': '#3887be',
              'line-width': 5,
              'line-opacity': 0.75
            }
          });
        }
    
        const bounds = new mapboxgl.LngLatBounds();
        route.forEach((point: [number, number]) => {
          bounds.extend(point);
        });
        this.map.fitBounds(bounds, {
          padding: 20
        });
      })
      .catch(error => console.error('Error fetching directions:', error));
    }
    
    
    private geocodeAddress(address: string): Promise<[number, number]> {
      const geocodeUrl = `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(address)}.json?access_token=${this.accessToken}`;
    
      return fetch(geocodeUrl)
        .then(response => response.json())
        .then(data => {
          if (data.features && data.features.length > 0) {
            const [lng, lat] = data.features[0].geometry.coordinates;
            return [lng, lat];
          } else {
            throw new Error('Address not found');
          }
        });
    }
    
  }
  
