import { AppComponent } from './app.component';
import { AppRoutingModule } from './app.routes';
import { AutocompleteComponent } from './autocomplete/autocomplete.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { DataService } from './data.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ItemFormComponent } from './item-form/item-form.component';
import { ItemListComponent } from './item-list/item-list.component';
import { MapBoxComponent } from './map-box/map-box.component';
import { NgModule } from '@angular/core';

@NgModule({
  declarations: [
    AppComponent,
    AutocompleteComponent,
    MapBoxComponent,
    ItemListComponent,
    ItemFormComponent

  ],
  imports: [
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [DataService],
  bootstrap:[AppComponent],
  exports:[MapBoxComponent, AutocompleteComponent, ItemListComponent, ItemFormComponent]
})
export class AppModule { }
