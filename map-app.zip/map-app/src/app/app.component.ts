import { Component, ViewChild } from '@angular/core';

import { MapBoxComponent } from './map-box/map-box.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  @ViewChild(MapBoxComponent) mapComponent!: MapBoxComponent;
  pickup: string = '';
  dropoff: string = '';

  onRouteSelected(event: { pickup: string, dropoff: string }) {
    this.pickup = event.pickup;
    this.dropoff = event.dropoff;
    this.mapComponent.displayRoute(event.pickup, event.dropoff);
  }
}
