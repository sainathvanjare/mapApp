import { Component, EventEmitter, Output } from '@angular/core';

declare const google: any;

@Component({
  selector: 'app-autocomplete',
  templateUrl: './autocomplete.component.html',
  styleUrls: ['./autocomplete.component.scss']
})
export class AutocompleteComponent {

  pickup: string = '';
  dropoff: string = '';

  @Output() routeSelected = new EventEmitter<{ pickup: string, dropoff: string }>();

  ngAfterViewInit(): void {
    this.initAutocomplete();
  }

  // private initAutocomplete() {
  //   const pickupInput = document.getElementById('pickup') as HTMLInputElement;
  //   const dropoffInput = document.getElementById('dropoff') as HTMLInputElement;

  //   const pickupAutocomplete = new google.maps.places.Autocomplete(pickupInput, { types: ['geocode'] });
  //   const dropoffAutocomplete = new google.maps.places.Autocomplete(dropoffInput, { types: ['geocode'] });

  //   pickupAutocomplete.addListener('place_changed', () => {
  //     const place = pickupAutocomplete.getPlace();
  //     this.pickup = place;
  //     console.log('Pickup Location: ', place.formatted_address);
  //   });

  //   dropoffAutocomplete.addListener('place_changed', () => {
  //     const place = dropoffAutocomplete.getPlace();
  //     this.dropoff = place;
  //     console.log('Dropoff Location: ', place.formatted_address);
  //   });
  // }

  private initAutocomplete() {
    const pickupInput = document.getElementById('pickup') as HTMLInputElement;
    const dropoffInput = document.getElementById('dropoff') as HTMLInputElement;

    const pickupAutocomplete = new google.maps.places.Autocomplete(pickupInput, { types: ['geocode'] });
    const dropoffAutocomplete = new google.maps.places.Autocomplete(dropoffInput, { types: ['geocode'] });

    pickupAutocomplete.addListener('place_changed', () => {
      const place = pickupAutocomplete.getPlace();
      if (place.formatted_address) {
        this.pickup = place.formatted_address;
        console.log('Pickup Location: ', this.pickup);
      }
    });

    dropoffAutocomplete.addListener('place_changed', () => {
      const place = dropoffAutocomplete.getPlace();
      if (place.formatted_address) {
        this.dropoff = place.formatted_address;
        console.log('Dropoff Location: ', this.dropoff);
      }
    });
  }
  submit() {
    this.routeSelected.emit({
      pickup: this.pickup,
      dropoff: this.dropoff
    });
  }
}